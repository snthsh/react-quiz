export {};
// export type Activity = {
//   activity_name: string;
//   order: number;
//   questions: string[];
// };

// export type QuizData = {
//   activities: Activity[];
//   heading: string;
//   name: string;
// };

// export const fetchQuizData = async () => {
//   const endpoint = `/interview.mock.data/payload.json`;
//   const quizData = await (await fetch(endpoint)).json();
//   return quizData;
// };
