export const BUTTONS_ARRAY = ['CORRECT', 'INCORRECT'];
export const TOTAL_QUESTIONS = 5;
export const API_URL = '/interview.mock.data/payload.json';
